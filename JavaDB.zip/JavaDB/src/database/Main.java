package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.Vector;

import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Main {

	public static void main(String[] args) throws Exception {

createTable();
post("Roman Sokolov", "5353", "SE-2021");

		

	}
	public static void updateTable(JTable table) throws Exception{
		int c;
		try {
			Connection con = getConnection();
			PreparedStatement statement =
					con.prepareStatement
					("SELECT * FROM records");
			ResultSet result = statement.executeQuery();
			ResultSetMetaData rmd = result.getMetaData();
			c = rmd.getColumnCount();
			
			DefaultTableModel df = (DefaultTableModel)table.getModel();
			df.setRowCount(0);
			
			while(result.next()) {
				Vector v2 = new Vector();
				
				for(int i = 1; i <= c; i++) {
					v2.add(result.getString("id"));
					v2.add(result.getString("Name"));
					v2.add(result.getString("Mobile"));
					v2.add(result.getString("Course"));
					}
				df.addRow(v2);
				
			}
			
		} catch(Exception e) {System.out.println(e);}
	}
	
	public static void delete(int id) throws Exception{
		try {
			Connection con = getConnection();
			PreparedStatement posted = 
					con.prepareStatement
					("DELETE  from records where id = ?");
			posted.setInt(1, id);


			
			posted.executeUpdate();
		} catch(Exception e) {System.out.println(e);}
		finally {
		}
	}
	
	public static void edit(int id, String name, String mobile, String course) throws Exception{
		try {
			Connection con = getConnection();
			PreparedStatement posted = 
					con.prepareStatement
					("UPDATE  records set Name = ?, mobile = ?, Course = ? where id = ?");
			posted.setString(1, name);
			posted.setString(2, mobile);
			posted.setString(3, course);
			posted.setInt(4, id);


			
			posted.executeUpdate();
		} catch(Exception e) {System.out.println(e);}
		finally {
		}
	}
	public static void post(String name, String mobile, String course) throws Exception{
		try {
			Connection con = getConnection();
			PreparedStatement posted = 
					con.prepareStatement
					("INSERT INTO records (Name, Mobile, Course) VALUES ('"+name+"','"+mobile+"','"+course+"')");
			posted.executeUpdate();
		} catch(Exception e) {System.out.println(e);}
		finally {
		}
	}
	
	
	
	public static void createTable() throws Exception {
		try {
			Connection con = getConnection();
			PreparedStatement create = 
					con.prepareStatement
					("CREATE TABLE IF NOT EXISTS records(id int NOT NULL AUTO_INCREMENT, Name varchar(255), Mobile varchar(255), Course varchar(255),PRIMARY KEY(id))");
			create.executeUpdate();
;		}catch(Exception e) {System.out.println(e);}
		finally {System.out.println("Function completed");}
		
	}
	
	public static Connection getConnection() throws Exception{
		try {
			String driver = "com.mysql.jdbc.Driver";
			String url = "jdbc:mysql://localhost:3306/sys";
			String username = "root";
			String password = "romsok207";
			Class.forName(driver);
			
			Connection conn = DriverManager.getConnection(url,username,password);
			return conn;
		} catch(Exception e) {System.out.println(e);}
		
		return null;
		
	}
 
}
